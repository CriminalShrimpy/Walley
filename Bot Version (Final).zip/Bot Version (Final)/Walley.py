import random
import json
import pickle
import numpy as np
import nltk
from keras.models import load_model
from nltk.stem import WordNetLemmatizer

lemm = WordNetLemmatizer()
dataset = json.loads(open("dataset.json").read())
vocab = pickle.load(open('vocab.pkl', 'rb'))
groups = pickle.load(open('groups.pkl', 'rb'))
botmodel = load_model('chatbotmodel.h5')

def clean_data(sentence):
	s_words = nltk.word_tokenize(sentence)
	s_words = [lemm.lemmatize(word)
					for word in s_words]
	return s_words

def bagofwords(sentence):
	s_words = clean_data(sentence)
	bag = [0]*len(vocab)
	for w in s_words:
		for i, word in enumerate(vocab):
			if word == w:
				bag[i] = 1
	return np.array(bag)

def predict_group(sentence):
	bag_w = bagofwords(sentence)
	res = botmodel.predict(np.array([bag_w]))[0]
	ERROR = 0.25
	results = [[i, r] for i, r in enumerate(res) if r > ERROR]
	results.sort(key=lambda x: x[1], reverse=True)
	output_list = []
	for r in results:
		output_list.append({'intent': groups[r[0]],
							'probability': str(r[1])})
	return output_list

def get_answer(list_meaning, meaning_json, confidence = 0.5):
	tag = list_meaning[0]['intent']
	intents_list = meaning_json['intents']
	output = ""
	for i in intents_list:
		if i['tag'] == tag:
			if float(list_meaning[0]['probability']) >= confidence:
				output = random.choice(i['responses'])
			else:
				print("Sorry, I don't understand :(")
			break
	return output


print("You're talking to Wall-E!")
while True:
	answer = input("You: ")
	if answer == 'quit': break
	meaning = predict_group(answer)
	response = get_answer(meaning, dataset, confidence=0.5)
	print("Wall-E:", response)