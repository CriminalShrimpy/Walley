# Personal Notes
# File Directory For Animations: 'D:\\University Work\\Year 3\\Semester 1\\CMPG313\\CMPG313 Group Project\\Bot Version (Final)\\Pet Animations'
# File Directory For Project: 'D:\\University Work\\Year 3\\Semester 1\\CMPG313\\CMPG313 Group Project\\Bot Version (Final)

# Python Libraries
import random # Pet moves randomly
import tkinter as tk # Used to create python GUI's
import pyautogui
import time

# Custom Libraries
import KeyPressRunBot # Run the bot when the up arrow is pressed on the keyboard

x = 1400
cycle = 0
check = 1
idle_num =[1, 2, 3, 4]
sleep_num = [10, 11, 12, 13, 15]
walk_left = [6, 7]
walk_right = [8, 9]
event_number = random.randrange(1, 3, 1)
impath = 'D:\\University Work\\Year 3\\Semester 1\\CMPG313\\CMPG313 Group Project\\Bot Version (Final)\\Pet Animations\\'

# Random number to event
def event(cycle, check, event_number, x):
    if event_number in idle_num:
        check = 0
        print('idle')
        window.after(400, update, cycle, check, event_number, x) # 1, 2, 3, 4 = idle
    elif event_number == 5:
        check = 1
        print('from idle to sleep')
        window.after(100, update, cycle, check, event_number, x) # 5 = idle to sleep
    elif event_number in walk_left:
        check = 4
        print('walking towards left')
        window.after(100, update, cycle, check, event_number, x)# 6, 7 = walk towards left
    elif event_number in walk_right:
        check = 5
        print('walking towards right')
        window.after(100, update, cycle, check, event_number, x)# 8, 9 = walk towards right
    elif event_number in sleep_num:
        check  = 2
        print('sleep')
        window.after(1000, update, cycle, check, event_number, x)# 10, 11, 12, 13, 15 = sleep
    elif event_number == 14:
        check = 3
        print('from sleep to idle')
        window.after(100, update, cycle, check, event_number, x)# 15 = sleep to idle

# Making gif work 
def gif_work(cycle, frames, event_number, first_num, last_num):
    #if cycle < len(frames) - 1:
    #    cycle += 1
    #else:
    #    cycle = 0
    
    if cycle < 0:
        cycle = len(frames) - 1
    elif cycle >= len(frames):
        cycle = 0

    event_number = random.randrange(first_num, last_num + 1, 1)

    return cycle, event_number

def update(cycle, check, event_number, x):
    global window

    # Idle
    if check == 0:
        print("Length of idle list: ", len((idle)))
        print("Cycle: ", cycle)
        frame = idle[cycle]
        cycle, event_number = gif_work(cycle, idle, event_number, 1, 9)
    # Idle to sleep
    elif check ==1:
        print("Length of idle to sleep list: ", len(idle_to_sleep))
        print("Cycle: ", cycle)
        frame = idle_to_sleep[cycle]
        cycle, event_number = gif_work(cycle, idle_to_sleep, event_number, 10, 10)
    # Sleep
    elif check == 2:
        print("Length of sleep list: ", len(sleep))
        print("Cycle: ", cycle)
        frame = sleep[cycle]
        cycle, event_number = gif_work(cycle, sleep, event_number, 10, 15)
    # Sleep to idle
    elif check ==3:
        print("Length of sleep to idle list: ", len(sleep_to_idle))
        print("Cycle: ", cycle)
        frame = sleep_to_idle[cycle]
        cycle, event_number = gif_work(cycle, sleep_to_idle, event_number, 1, 1)
    # Walk toward left
    elif check == 4:
        print("Length of walk towards left list: ", len(walk_negative))
        print("Cycle: ", cycle)
        frame = walk_positive[cycle]
        cycle, event_number = gif_work(cycle,walk_positive,event_number, 1, 9)
        x -= 3
    # Walk towards right
    elif check == 5:
        print("Length of walk towards right list: ", len(walk_positive))
        print("Cycle: ", cycle)
        frame = walk_negative[cycle]
        cycle, event_number = gif_work(cycle, walk_negative, event_number, 1, 9)
        x += 3

    window.geometry('100x100+' + str(x) + '+1050')
    label.configure(image = frame)  
    delay = 10
    window.after(1, event, cycle, check, event_number, x)

window = tk.Tk()

# Call Walley's action gifs
idle = [tk.PhotoImage(file = impath + 'idle.gif', format = 'gif -index %i' %(i)) for i in range(5)] # Idle gif
idle_to_sleep = [tk.PhotoImage(file = impath + 'idle_to_sleep.gif', format = 'gif -index %i' %(i)) for i in range(8)] # Idle to sleep gif
sleep = [tk.PhotoImage(file = impath + 'sleep.gif', format = 'gif -index %i' %(i)) for i in range(3)] # Sleep gif
sleep_to_idle = [tk.PhotoImage(file = impath + 'sleep_to_idle.gif', format = 'gif -index %i' %(i)) for i in range(8)] # Sleep to idle gif
walk_positive = [tk.PhotoImage(file = impath + 'walking_positive.gif', format = 'gif -index %i' %(i)) for i in range(8)] # Walk to left gif
walk_negative = [tk.PhotoImage(file = impath + 'walking_negative.gif', format = 'gif -index %i' %(i)) for i in range(8)] # Walk to right gif

#window configuration
window.config(highlightbackground = 'black')
label = tk.Label(window, bd = 0, bg = 'black')
window.overrideredirect(True)
window.wm_attributes('-transparentcolor','black')
label.pack()

#loop the program
window.after(1000, update, cycle, check, event_number, x)
window.mainloop()