import keyboard
import subprocess

def run_on_up_arrow(program_path):
    # Handle key events for the up arrow key
    def handle_up_key(event):
        if event.event_type == 'down' and event.name == 'up':
            # Run the specified program
            subprocess.run(program_path)

    # Register the key event handler for the up arrow key
    keyboard.on_press(handle_up_key)

def run_on_down_arrow(program_path):
    # Handle key events for the down arrow key
    def handle_down_key(event):
        if event.event_type == 'down' and event.name == 'down':
            # Run another program when the down arrow key is pressed
            subprocess.run(program_path)

    # Register the key event handler for the down arrow key
    keyboard.on_press(handle_down_key)

#def main():
#    run_on_up_arrow("D:\\University Work\\Year 3\\Semester 1\\CMPG313\\CMPG313 Group Project\\Bot Version (Final)\\Walley (GUI).py")
#    run_on_down_arrow("D:\\University Work\\Year 3\\Semester 1\\CMPG313\\CMPG313 Group Project\\Bot Version (Final)\\Walley Pet.py")

def main():
    # Use the following line of code to run the program for the up arrow key (Change the directory)
    run_on_up_arrow("D:\\University Work\\Year 3\\Semester 1\\CMPG313\\CMPG313 Group Project\\Bot Version (Final)\\Walley (GUI).py")

    # Use the following line of code to run the program for the down arrow key (Change the directory)
    run_on_down_arrow("D:\\University Work\\Year 3\\Semester 1\\CMPG313\\CMPG313 Group Project\\Bot Version (Final)\\Walley Pet.py")

    try:
        keyboard.wait()
    except KeyboardInterrupt:
        pass
    finally:
        # Unhook all key event handlers
        keyboard.unhook_all()

# Run the main function
if __name__ == '__main__':  
    main()